def tidblanda(antal):
    tid = 10 + antal
    print "Tid�tg�ngen f�r att blanda smeten �r",tid,"minuter f�r",antal,"personer"

