def recept(antal):
  print "Ingredienser till sockerkaka f�r" ,antal, "personer"
  smor = (antal*10.0)/4
  print "Till formen:"
  print "ca",smor,"gram sm�r"

  strobrod = (antal*0.75)/4
  print "ca",strobrod,"dl str�br�d"

  print "Till sockerkaka:"
  agg = (antal*3)/4
  print agg,"st agg"

  strosocker = (antal*3.0)/4
  print strosocker,"dl str�socker"

  vaniljsocker = (antal*2.0)/4
  print vaniljsocker,"tsk vaniljsocker"

  bakpulver = (antal*2.0)/4
  print bakpulver,"tsk bakpulver"

  vetemjol = (antal*3.0)/4
  print vetemjol,"tsk vetemj�l"

  smor1 = (antal*75.0)/4
  print smor1,"g sm�r"

  vatten = (antal*1.0)/4
  print vatten,"dl vatten"

  #2.1
def tidblanda(antal):
   tid1 = 10 + antal
   return tid1 #Ingen text pga av att de ska summeras ihop. String och Int g�r ej ihop

#2.2
def tidgadda(antal):

   tid2 = 30 + 3*antal
   return tid2 #Ingen text pga av att de ska summeras ihop. String och Int g�r ej ihop

def sockerkaka(antal):
 recept(antal)
 print "Total tid", tidblanda(antal) + tidgadda(antal), "minuter"
