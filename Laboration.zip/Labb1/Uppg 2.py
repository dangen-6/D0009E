#2.1
def tidblanda(antal):
    tid = 10 + antal
    print "Tid�tg�ngen f�r att blanda smeten �r",tid,"minuter f�r",antal,"personer"

#2.2
def tidgadda(antal):

     tid = 30 + 3*antal
     print "Tids�tg�ng f�r gr�ddning:",tid,"minuter f�r",antal,"personer"
