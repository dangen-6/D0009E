def tidgadda(antal):

     tid = 30 + 3*antal
     print "Tids�tg�ng f�r gr�ddning:",tid,"minuter f�r",antal,"personer"
