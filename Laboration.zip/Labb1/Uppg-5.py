

#k = P + (a+1)*Pr/2
#k = total kostnad
#P = l�nade beloppet
#r = r�ntesatsen
#a = antal �r f�r r�nte�terbetalning
def kostnad(P, r, a):
    k = P + (a+1)*P*r/2
    print "Den totala kostnaden efter",a,"�r �r",int(k),"kr."



#-*- coding: cp1252 -*-

