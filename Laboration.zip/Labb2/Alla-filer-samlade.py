#Labb 2

#Uppgift 1
def bounce(n):
    if n == 0:
     print 0,
    else:
     print(n), #R�knar fr�n n->0
     bounce(n-1)
     print(n), #R�knar fr�n 0->n
bounce(5)




#Uppgift 2
def bounce2(n):
    for i in range(n,0,-1): #B�rjar med n, slutar med 0, g�r med -1 steg per loop
        print i,
    for i in range(n+1): #N�r n=0 som �r l�gsta range r�knas n upp med 1 steg till h�gsta range n=inputv�rde
        print i,
bounce2(4)




#Uppgift3
def tvarsumman(n):
    if n == 0:
     return 0
    else:
     return (n%10) + tvarsumman(n/10) #n%10 kollar vilken rest du f�r, n/10 �r f�r att f� resten av de
print tvarsumman(123)

# 123%10 = 3
# 123/10 = 12

# 15%10 = 5
# 15/10 = 1

# 6%10 = 6
# 6/10 = 0

#import d0009e_lab2_sumTest




#Uppgift 4
def tvarsumman2(n):
    i = 0
    while n > 0:
        i = i +  n%10
        n = n/10
    return i
print tvarsumman2(223)
#import d0009e_lab2_sumTest

# Uppgift 5
# a)

# f = funktionen
# x = punkten d�r lutningen ska s�kas i
# h = hur mycket �t sidan vi ska titta, hur noga vi ska vara
import math
def derivative(f, x, h):
    n = (f(x + h)-f(x - h))/(2*h)
    return float(n)

print derivative(math.cos, math.pi, 0.0001) # y=cosx runt pi. y'=-sinx runt pi ger -sin(pi) = 0 
print derivative(math.sin, math.pi, 0.0001) # y=sinx runt pi. y'=cosx runt pi ger cos(pi) = -1
print derivative(math.sin, math.pi/3, 0.0001) # y=sinx runt pi/3. y'=cosx runt pi cos(pi/3) = 1/2

# Svaren blir inte helt exakt p� grund av l�ngden h man g�r �t sidan. Ju l�ngre h desto st�rre s�kerhet

#b)
# f = funktionen
# x0 = startpunkten
# h = noggrannheten
# xn1 = xn+1
# fxn = f(xn)

def solve(f, x0, h):
    xn = x0
    xn1 = xn + h*10 # Hoppar ett steg n�rmre 
    while abs(xn - xn1) > h: # Skillnaden i x-led mellan tv� iterationer �r mindre �n h s� �r ber�kningen klar
        fxn = f(xn)
        xn = xn1 #Detta blir "nya" xn
        xn1 = xn - (fxn/derivative(f, xn, h))
    return xn1


def test1():
    return lambda x: x**2 - 1

n1 = solve(test1(), -0.5, 0.0000000001)    # call the solver
print "Nollst�llen: X = ", n1

def test2():
    return lambda x: 2**x -1
n2 = solve(test2(), 0, 0.000001)
print "Nollst�llen: X = ", n2

def test3():
    return lambda x: x-math.exp(-x)
n3 = solve(test3(), 1, 0.00001)
print "Nollst�llen: X = ", n3
