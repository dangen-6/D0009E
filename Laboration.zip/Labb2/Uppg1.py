#Labb 2 uppgift 1

def bounce(n):
    if n == 0:
     print 0, #Skriver ut n d� 
    else:
        print(n), #R�knar fr�n n->0
        bounce(n-1)
        print(n), #R�knar fr�n 0->n
bounce(4)

