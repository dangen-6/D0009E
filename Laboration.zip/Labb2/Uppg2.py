def bounce2(n):
    for i in range(n,0,-1): #b�rjar med n, slutar med 0, g�r med -1 steg per loop
        print i,
    for i in range(n+1): #N�r n=0 som �r l�gsta range r�knas n upp med 1 steg i taget till h�gsta range n=input-v�rde
        print i,
bounce2(4)
