#Uppgift 3

def tvarsumman(n):
 if n == 0:
  return 0
 else:
  return (n%10) + tvarsumman(n/10) #n%10 kollar vilken rest du f�r, n/10 �r f�r att f� resten av de 
print tvarsumman(223)

# 123%10 = 3
# 123/10 = 12

# 15%10  = 5
# 15/10  = 1

# 6%10   = 6
# 6/10   = 0

# Kvar �r d� 6

#import d0009e_lab2_sumTest
