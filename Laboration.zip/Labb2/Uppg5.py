# Uppgift 5
# a)

# f = funktionen
# x = punkten d�r lutningen ska s�kas i
# h = hur mycket �t sidan vi ska titta, hur noga vi ska vara
import math
def derivative(f, x, h):
    n = (f(x + h)-f(x - h))/(2*h)
    return float(n)

print derivative(math.cos, math.pi, 0.0001) # y=cosx runt pi. y'=-sinx runt pi ger -sin(pi) = 0 
print derivative(math.sin, math.pi, 0.0001) # y=sinx runt pi. y'=cosx runt pi ger cos(pi) = -1
print derivative(math.sin, math.pi/3, 0.0001) # y=sinx runt pi/3. y'=cosx runt pi cos(pi/3) = 1/2

# Svaren blir inte helt exakt p� grund av l�ngden h man g�r �t sidan. Ju l�ngre h desto st�rre s�kerhet

#b)
# f = funktionen
# x0 = startpunkten
# h = noggrannheten
# xn1 = xn+1
# fxn = f(xn)

def solve(f, x0, h):
    xn = x0
    xn1 = xn + h*10 # Hoppar ett steg n�rmre 


    while abs(xn - xn1) > h: # Skillnaden i x-led mellan tv� iterationer �r mindre �n h s� �r ber�kningen klar
        fxn = f(xn)
        xn = xn1 #Detta blir "nya" xn
        #xn = xn - (fxn/derivative(f, xn, h))
        xn1 = xn - (fxn/derivative(f, xn, h))
    return xn1


def test1():
    return lambda x: x**2 - 1

n1 = solve(test1(), -0.5, 0.0000000001)    # call the solver
print "Nollst�llen: X = ", n1

def test2():
    return lambda x: 2**x -1
n2 = solve(test2(), 0, 0.000001)
print "Nollst�llen: X = ", n2

def test3():
    return lambda x: x-math.exp(-x)
n3 = solve(test3(), 1, 0.00001)
print "Nollst�llen: X = ", n3
