#Uppgift 4

def tvarsumman2(n):
    i = 0
    while n > 0:
        i = i +  n%10
        n = n/10
    return i
print tvarsumman2(123)
import d0009e_lab2_sumTest
