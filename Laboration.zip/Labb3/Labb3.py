def huvudmeny():
 print "1. Tv� str�ngar \n2. Tupler \n3. Ordlista \n4. Avsluta"
 val = raw_input("Val av alternativ: ")
 if val == '1': 
     Strangar()
 elif val == '2': 
     Tupler()
 elif val == '3':
     Ordlista()
 elif val == '4':
     print "Programmet avslutas"
 else:
     print "V�nligen skriv in en siffra mellan 1-4, �terg�r till huvudmeny"
     huvudmeny()

     
def Strangar():
    strang1 = [] #Ordet vi l�gger till
    strang2 = [] #Beskrivningen
    x = True
    while x:   
     alternativ = raw_input("1. Insert \n2. Lookup \n3. Avsluta programmet \nVal av alternativ: ")
     def A1():
        word = raw_input("Skriv in ditt ord: ") 
        if word in strang1:
            print "Ordet finns redan"
        else:
            strang1.append(word) #L�gger till ordet i lista1
            definition = raw_input("Skriv ordets beskrivning: ") 
            strang2.append(definition)    #Ordet blir nyckel och definition blir v�rdet      

     def A2():
        word = raw_input("Skriv ordet du vill sl� upp i listan: ")
        if word in strang1: #Kollar om ordet vi skrev in finns i lista 1
      
            pos = strang1.index(word) #Kollar positionen i v�rat ord har i lista 1
            print strang2[pos] #Skriver samma positionen fast i lista 2
            print strang1[pos]
        else:
            print "Ordet finns ej i n�gon lista"
            
     def A3():
        print "Programmet avslutas. Lista 1:", strang1,"Lista2:", strang2
     while True:

        if alternativ == '1':
            A1()
            break  
        if alternativ == '2':
            A2()
            break
        if alternativ == '3':
            A3()
            x = False #S� att loopen bryts
            
        else:
            print "V�nligen v�lj mellan alternativ 1-3"
            alternativ = raw_input("1. Insert \n2. Lookup \n3. Avsluta programmet \nVal av alternativ: ")


def Tupler():
    tupl = []
    x = True
    while x:   
     alternativ = raw_input("1. Insert \n2. Lookup \n3. Avsluta programmet \nVal av alternativ: ") #Meny
     def A1():
         word = raw_input("Skriv in ditt ord: ")
         word1 = [x for x,y in tupl] #P� plats "x", x-koordinat. X f�r ordet och Y f�r beskrivning
         if word in word1: #Kollar ifall ordet vi skrev in redan finns
             print "Ordet finns redan"
         else:
             definition = raw_input("Skriv in ordets beskrivning: ")
             data = (word, definition) #L�gger ihop paret
             tupl.append(data) #L�gger in en tupel i ordlistan

     def A2():
          word = raw_input("Skriv ordet du vill sl� upp i listan: ")
          word1= [x for x,y in tupl] #X �r ordet
          if (word in word1): #Kollar ifall det ordet vi skriver in finns i tuplern
              for k in range(0, len(tupl)): #Kolla f�rsta ordet i varje tupel och kollar igenom alla
                  if word1[k] == word: #Om ordet du skriver in finns i tupel
                      print tupl[k][1] #Skriver ut beskrivningen
          else:
              print "Ordet finns inte i tupeln."
            
     def A3():
        print "Programmet avslutas.", tupl

     while True:
        if alternativ == '1':
            A1()
            break  
        if alternativ == '2':
            A2()
            break
        if alternativ == '3':
            A3()
            x = False #S� att loopen bryts
            break
        else:
            print "V�nligen v�lj mellan alternativ 1-3"
            alternativ = raw_input("1. Insert \n2. Lookup \n3. Avsluta programmet \nVal av alternativ: ")



def Ordlista():
 ordlista = {}
 x = True
 while x: #En variabel som m�ste st�mma f�r att loopen ska k�ras
     alternativ = raw_input("1. Insert \n2. Lookup \n3. Avsluta programmet \nVal av alternativ: ") #H�r skriver du in ifall du vill l�gga till ord, sl� upp ord eller avsluta programmet

     def A1():
       word = raw_input("Skriv ordet du vill l�gga in i ordlistan: ")
       if word in ordlista: #Kollar ifall ordet redan finns i v�r ordlista
          print "Ordet finns redan!"
       else:
        definition = raw_input("Skriv ordets beskrivning: ") 
        ordlista[word] = definition    #Ordet blir nyckel och definition blir v�rdet
        print "Nyckel:" , word, "V�rde:" , definition
      
     def A2():
       word = raw_input("Skriv ordet du vill sl� upp i ordlistan: ")
       if word in ordlista.keys(): #Kollar ifall ordet vi vill l�gga till finns i ordlistan
          print ordlista[word] #Skriver ut v�rdet p� ordet
       else:              
          print "Ordet finns ej i ordlistan."

     def A3():
      print "Programmet avslutas"
      print "Ordlistan", ordlista
       
     while True:
      if alternativ == '1':
         A1()
         break
      if alternativ == '2':
         A2()
         break
      if alternativ == '3':
         A3()
         x = False
         break
      else:
        print "V�nligen v�lj mellan alternativ 1-3"
        alternativ = raw_input("1. Insert \n2. Lookup \n3. Avsluta programmet \nVal av alternativ: ")

huvudmeny()
