prompt = ("\ntelebok> (add/lookup/alias/change/save/load/quit/) \nSkriv in ditt comando h�r: ")
telebok = {}
run = True




while run:
 command = raw_input(prompt)

 def add(): #L�gger till namn och nummer
    namn = raw_input("Namn: ")
    if namn in telebok: 
          print "Namnet finns redan inlagt i teleboken."
    else:
          b = {y:x for x,y in telebok.items()}
          nummer = raw_input("Nummer: ")
          if nummer in b:
           print "Numret finns redan"

          else:
           telebok[namn] = nummer
           print namn, nummer

 def change():
    namn = raw_input ("Name?:")
    if namn in telebok:
        b = {y:x for x,y in telebok.items()}
        nummer = raw_input("Nummer: ")
        if nummer in b:
           print "Numret finns redan"

        else:
           telebok[namn] = nummer
           print namn, nummer
    else:
          print "Personen finns ej"

 def alias():
     print "hej"


 
 def lookup(): #S�ker upp nummer via namnet
    namn=raw_input ("Namn: ")
    if namn in telebok:
        print telebok[namn]
    else:
        print "Namnet finns inte inlagt teleboken."

 def avsluta():
     print "Programmet avslutas"
     print telebok




 while True:
  if command == 'quit':
     avsluta()
     run = False
     break
     

  elif command == 'add':
     add()
     break

  elif command == 'lookup':
      lookup()
      break
    
  elif command == 'alias':
       alias()
       
  elif command == 'change':
       change()
       break
  else:
       print "Skriv in annat kommando."
       break
       prompt = ("\ntelebok> (add/lookup/alias/change/save/load/quit/) \nSkriv in ditt comando h�r: ") 
